﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hagowartz
{
    internal class Teacher:AuthorizedPersons
    {
        public Teacher(Human h):base(h) { }
        
        public bool SimultaneousTeaching { get; set; }
    }
}
