﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hagowartz
{
    internal class JsonDataParser
    {
        public String name { get; set; }
        public String family { get; set; }
        public String dateOfBirth { get; set; }
        public String gender { get; set; }
        public String father { get; set; }
        public String username { get; set; }
        public String password { get; set; }
        public String type { get; set; }
        public String role { get; set; }
    }
}
