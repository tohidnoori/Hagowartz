﻿namespace Hagowartz
{
    public class Lesson
    {
        public int Capicity { get; set; }
        public int StuNum { get; set; }
        public string Time { get; set; }
        public string Name { get; set; }
        public int OfferedTerm { get; set; }

    }
}