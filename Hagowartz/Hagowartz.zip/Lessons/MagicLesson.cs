﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hagowartz
{
    internal class MagicLesson
    {
        public List<String> MagicList { get; set; }
    }
}
