﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hagowartz.Lessons
{
    internal class Sport
    {
        public String Type { get; set; }
    }
}
