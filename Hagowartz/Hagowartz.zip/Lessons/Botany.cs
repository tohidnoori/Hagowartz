﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hagowartz
{
    internal class Botany
    {
        public List<Plant> Term1PlantList { get; set; }
        public List<Plant> Term2PlantList { get; set; }
        public List<Plant> Term3PlantList { get; set; }
        public List<Plant> Term4PlantList { get; set; }
    }
}
